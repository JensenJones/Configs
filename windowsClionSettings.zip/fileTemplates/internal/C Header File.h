#[[#pragma]]# once

